<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $title; ?></title>
        <base href="http://localhost/blog/" />
    </head>
    <body>
        <?php echo $content; ?>
        <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/common.js"></script>
    </body>
</html>

