<?php


require_once './constants.php';
require_once './Exception/CustomException.php';
require_once './Bootstrap.php';

$bootstrap = new Bootstrap();
$bootstrap->execute();
